#include <stdio.h>
#include <stdlib.h>
#include "HW6-Q3.h"



int main(void) {
  board();
  players_turn(1);
  return 0;
}



