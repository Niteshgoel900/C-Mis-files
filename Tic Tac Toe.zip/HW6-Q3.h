char square[10] = {'0','1','2','3','4','5','6','7','8','9'}; 
int player=1;
int i=0;

void board(void);
void players_turn(int player);
void gamestatus(void);


void board(void){
  printf("Player 1:(X) - Player 2(O)\n\n");
	printf("\n\t\t\t       |       |       ");
	printf("\n\t\t\t   %c   |   %c   |   %c   ",square[1], square[2], square[3]);
	printf("\n\t\t\t-------|-------|-------");
	printf("\n\t\t\t   %c   |   %c   |   %c   ",square[4], square[5], square[6]);
	printf("\n\t\t\t-------|-------|-------");
	printf("\n\t\t\t   %c   |   %c   |   %c   ",square[7], square[8], square[9]);
	printf("\n\t\t\t       |       |       ");
}

void players_turn(int player){
  int p=1;
  int Player_chooses;
  while (1){
    if (player==1) {
      printf("Player %d's turn:", p);
      scanf("%d", & Player_chooses); 
      if (!(square[Player_chooses] == 'O' || square[Player_chooses] == 'X')) {
        square[Player_chooses] = 'X'; 
        board();
        p=2; 
        i++;
        gamestatus();
      } 
      else{
        printf("Please enter a different number: "); 
          scanf("%d", & Player_chooses); 
          square[Player_chooses] = 'O';
          printf("\n\nPlayer 1 (X) - Player 2 (O) \n");
          board();
          p = 1; 
          i++;
          gamestatus();
      }
    } 
    if (p==2){
      printf("Player %d enter a number:", p);
      scanf("%d", &Player_chooses); 
      if (square[Player_chooses]!='O' || square[Player_chooses] != 'X') {
        square[Player_chooses] = 'O';
        board();
        p = 1;
        i++;
        gamestatus();
      } 
      else{
        printf("Please enter a different number"); {
          scanf("%d", & Player_chooses); 
          square[Player_chooses] = 'O'; 
          board(); 
          p = 1;
          i++;
          gamestatus();
        }
      }
    }
  }
}

void gamestatus(void){
  if (i == 9){
    printf("\n\t\t\tIt's not possible for anyone to win\n");
    exit(0);
  }
  else{
    //diagnoals
    if (square[1]==square[5])
      if(square[5] == square[9]){
        if(square[1]=='X')
          printf("Player 1 wins!");
        else
          printf("Player 2 wins!");
        exit(0);
      }
    if (square[3] == square[5])
      if(square[5] == square[7]){
        if(square[3]=='X')
          printf("Player 1 wins!");
        else
          printf("Player 2 wins!");
        exit(0);
      }
    
    //horizontal
    if (square[1] == square[2])
      if(square[2] == square[3]){
        if(square[1]=='X')
          printf("Player 1 wins!");
        else
          printf("Player 2 wins!");
        exit(0);              
      }
    //horizontal
    if (square[4] == square[5])
      if(square[5] == square[6]){
        if(square[4]=='X')
          printf("Player 1 wins!");
        else
          printf("Player 2 wins!");
        exit(0);
      }
    //horizontal
    if (square[7] == square[8])
      if(square[8] == square[9]){
        if(square[7]=='X')
          printf("Player 1 wins!");
        else
          printf("Player 2 wins!");
        exit(0);
      }
    
    //vertical
    if (square[1] == square[4])
      if(square[4] == square[7]){
        if(square[1]=='X')
          printf("Player 1 wins!");
        else
          printf("Player 2 wins!");
        exit(0);
      }
    //vertical
    if (square[2] == square[5])
      if (square[5] == square[8]){
        if(square[2]=='X')
          printf("Player 1 wins!");
        else
          printf("Player 2 wins!");
        exit(0);
      }
    //vertical
    if (square[3] == square[6])
      if(square[6] == square[9]){
        if(square[3]=='X')
          printf("Player 1 wins!");
        else
          printf("Player 2 wins!");
        exit(0);
      }
  }
}