//  main.c
//  Final Lab Quiz
//
//  Created by Nitesh Goel on 7/22/19.
//  Copyright © 2019 Nitesh Goel. All rights reserved.
//
#include <stdio.h>
#include <stdlib.h>

struct tree_node {
  int data;
  int count;
  struct tree_node *left;
  struct tree_node *right;
}*root, *root2;

struct tree_node* insert(struct tree_node *root, struct tree_node *element);
struct tree_node* create_node(int val, int x);
void inorder(struct tree_node *current_ptr);
int house_count(struct tree_node *root);

int main(void) 
{
  int number_tree1, number_tree2;
  int price, count;
  struct tree_node *temp, *temp2;
  temp = (struct tree_node*)malloc(sizeof(struct tree_node));
  temp2 = (struct tree_node*)malloc(sizeof(struct tree_node));
  FILE *infile1 = fopen("in1.txt", "r");
  
  if (infile1 == NULL)
   {
       puts("Error: Could not open first file");
       return 0;
   }

  fscanf(infile1, "%d", &number_tree1);
  FILE *infile2 = fopen("in2.txt", "r");
  if (infile2 == NULL)
   {
       puts("Error: Could not open second file");
       return 0;
   }

  fscanf(infile2, "%d", &number_tree2);

  for(int i=0; i<number_tree1; i++)
  {
    fscanf(infile1, "%d %d", &price, &count);
    temp = create_node(price, count); 
    root = insert(root, temp);
  }

  for(int i=0; i<number_tree2; i++)
  {
    fscanf(infile2, "%d %d", &price, &count);
    temp2 = create_node(price, count); 
    root2 = insert(root2, temp2);
  }

  printf("\nTrees constructed from file");
  printf("\nIn-order tree 1: ");
  inorder(root);
  printf("\nIn-order tree 2: ");
  inorder(root2);
  printf("\nTotal houses in tree 1: %d",house_count(root));
  printf("\nTotal houses in tree 2: %d",house_count(root2));
  if(house_count(root) > house_count(root2))
    printf("\nTree 1 has the highest number of houses.");
  else if(house_count(root2) > house_count(root))
    printf("\nTree 2 has the highest number of houses.");
  else
    printf("\nBoth trees have same number of houses.");
}


struct tree_node* insert(struct tree_node *root, struct tree_node *element) 
{
  if (root == NULL)
  {
    return element;
  }
  else 
  {
    if (element->data > root->data) 
    {
      if (root->right != NULL)
        root->right = insert(root->right, element);
      else
        root->right = element;
    }
    else 
    {
      if (root->left != NULL)
        root->left = insert(root->left, element);
      else
        root->left = element;
    }
    return root;
  }
}

//Save the data in a new node for BST
struct tree_node* create_node(int val, int x) 
{
  struct tree_node* temp;
  temp = (struct tree_node*)malloc(sizeof(struct tree_node));
  temp->data = val;
  temp->count = x;
  temp->left = NULL;
  temp->right = NULL;
  return temp; 
}

void inorder(struct tree_node *current_ptr) 
{
  if (current_ptr != NULL) 
  {
    inorder(current_ptr->left); 
    printf("(%d, %d), ", current_ptr->data, current_ptr->count);
    inorder(current_ptr->right);
  }
}

int house_count(struct tree_node *root)
{
  if(root == NULL)
    return 0;
  return root->count + house_count(root->left) + house_count(root->right);
}



