
/*PROJECT NO.:   11
  PROJECT TITLE: THE TORTOISE AND THE HARE
  MEMBERS:       Nitesh Goel, Eshika Sahay
  TOTAL POINTS:  100*/


#include "fp1.h"
  
int main(void)
{
   int tortoise=1, hare=1, counter=0;
   srand (time(0));
   //the game starts
   printf ("Tortoise and Hare Race\n");
   printf ("BANG !!!!! AND THEY'RE OFF !!!!!\n\n");
   while (tortoise!=FINISH && hare!=FINISH)
   {
      //tortoise moves
      moveTortoise(&tortoise);
      //hare moves
      moveHare(&hare);
      //show the current position of hare and tortoise
      printPosition(&tortoise, &hare); 
      counter++;      
   }
   if (tortoise<hare)
      //if hare wins
      printf ("\nHare wins. Yuch. \n");     
   else if (tortoise>hare)
      //if tortoise wins
      printf ("\nTORTOISE WINS!!! YAY!!!\n");
   else
      //if it's a tie
      printf ("\nIt's a tie\n"); 
   //total time elapsed        
   printf ("Time: %d seconds\n", counter); 
   return 0;
}
 
