#include<stdio.h>
#include<stdlib.h>
#include<time.h>
 
//global variable
#define FINISH 70

//function prototype
void moveTortoise (int* tortoisePtr);
void moveHare (int* harePtr);
void printPosition (const int* const tortoisePtr, const int* const harePtr);
  
void moveTortoise (int* tortoisePtr)
{
   int i;
   i=rand()%10;
   if (i>=1 && i<=5) //50% chance
      //moves the tortoise 3 squares to the right (fast plod)
      *tortoisePtr+=3;  
   else if (i>=6 && i<=7) //20% chance
      //moves the tortoise 6 squares to the left (slip)
      *tortoisePtr-=6; 
   else //30% chance
      //moves the tortoise 1 square to the right (slow plod)  
      *tortoisePtr+=1; 
    
   if (*tortoisePtr<1)
      *tortoisePtr=1;
   else if (*tortoisePtr>FINISH)
      *tortoisePtr=FINISH;
}
 
void moveHare (int* harePtr)
{
   int i;
   i=rand()%10;
   if (i>=1 && i<=2) //20% chance
      //no move because the hare fell asleep
      *harePtr=*harePtr; 
   else if (i>=3 && i<=4) //20% chance 
      //moves the hare 9 squares to the right (big hop)
      *harePtr+=9; 
   else if (i==5) //10% chance
      //moves the hare 12 squares to the left (big slip)
      *harePtr-=12; 
   else if (i>=6 && i<=8) //30% chance
      //moves the hare 1 square to the right (small hop)
      *harePtr+=1; 
   else //20% chance
      //moves the hare 2 squares to the left (small slip)
      *harePtr-=2;  
   
   if (*harePtr<1)
      *harePtr=1;
   else if (*harePtr>FINISH)
      *harePtr=FINISH;
}
 
void printPosition(const int* const tortoisePtr, const int* const harePtr)
{
   int i;
   //printing "OUCH" when they both are at the same position
   if (*tortoisePtr==*harePtr)
   {
      for(i=1; i<*tortoisePtr; i++)
         printf (" ");
      printf ("OUCH!!!\n");                
   }
   //T is printed before H
   else if (*tortoisePtr<*harePtr)
   {
      for (i=1; i<*tortoisePtr; i++)
         printf (" ");   
      printf ("T"); 
      for (i=1; i<(*harePtr-*tortoisePtr); i++)
         printf (" ");
      printf ("H\n");
   }
   //H is printed before T
   else
   {
      for (i=1; i<*harePtr; i++)
         printf (" ");          
      printf ("H");
      for (i=0; i<(*tortoisePtr-*harePtr); i++)
         printf (" ");     
      printf ("T\n");
   }
}