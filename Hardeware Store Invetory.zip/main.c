#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct Tool{
  int    row;
  char   name[50];
  int    quantity;
  double cost;
};

//function prototypes
void item(struct Tool x);
void All_Tools();
void Add_tool(struct Tool x);
void Add_tool(struct Tool x);
void add_tools(void);
void tool_remover_index(int x);
void edit_tool(void);
void remove_tool(void);
void writeToFile(void);
//function prototypes
char *p(long int i,char*s,int temp);
char *getitem_string(struct Tool x);
char *p(long int i,char*s,int temp);
char *getitem_string(struct Tool x);
//function prototypes
int tool_index(int x);
//function prototypes
struct Tool tool_get(int x);
struct Tool Line(char myTool[]);

struct Tool tools[100];
char   item_string[50];
char   x[50];

int main(void){
  FILE* fp;
    char temp[255];
    fp=fopen("hardware.dat","r");
    int l=0;
    while(fgets(temp,255,(FILE*) fp)){
      if(l==0){
        for(int i=0;i<48;i++){
          if(temp[i]!='\n'){
            x[i]=temp[i];
          }
        }
      }
      if(l>0){
        struct Tool tool=Line(temp);
        tools[l-1]=tool;
      }
      l++;
    }
    fclose(fp);
    int userIn=0;
    while(userIn!=6){
      printf("\n-------------------------------------------\n");
      printf("1-to list all tools\n");
      printf("2-to add a tool\n"); 
      printf("3-to modify an existing record\n");  
      printf("4-to delete a record\n"); 
      printf("5-to exit\n");
      printf("Enter:");
      int j;
      scanf("%d",&j);
      userIn=j;
      //no defult needed
      switch(userIn){
        case 1:
          All_Tools();
          break;
        case 2:
          add_tools();
          writeToFile();
          break;
        case 3:
          edit_tool();
          writeToFile();
          break;
        case 4:
          remove_tool();
          writeToFile();
          break;
        case 5:
          printf("You have decided to exit from the program!!\n");
          return 0;
      }
    }
    writeToFile();
  return 0;
};
void item(struct Tool x){
  printf("\n%d, %s, %d, %lf",x.row,x.name,x.quantity,x.cost);
};
void All_Tools(){
  printf("\n-------------------------------------------");
  printf("\nRecord Number, Tool, Quantitiy, Price");
  for(int i=0;i<100;i++){
    if(tools[i].row!=0){
      item(tools[i]);
    }
  }
};
void Add_tool(struct Tool x){
  for(int i=0;i<100;i++){
    if(tools[i].row==0){
      tools[i]=x;
      break;
    }
  }
};
void add_tools(void){
  struct Tool new_tool;
  int    row; 
  char   name[24];
  int    quantity;
  double cost;
  printf("-------------------------------------------");
  printf("\nWhat is the tool record #?\n");
  scanf("%d",&row);
  printf("What is the tool tool name?\n");
  scanf("%s",&name);
  printf("What is the tool quantity?\n");
  scanf("%d",&quantity);
  printf("What is the tool price?\n");
  scanf("%lf",&cost);
  printf("-------------------------------------------\n");
  new_tool.row=row;
  
  for(int i=0;i< 24;i++){
    new_tool.name[i]=name[i];
  }
  new_tool.quantity=quantity;
  new_tool.cost=cost;
  Add_tool(new_tool);
  All_Tools();
};
void tool_remover_index(int x){
  int index=tool_index(x);
  tools[index].row=0;
  tools[index].name[0]='\0';
  tools[index].quantity=0;
  tools[index].cost=0;
};
void edit_tool(void){
  struct Tool oldTool;
  int index;
  int row; 
  char name[50];
  int quantity;
  double cost;
  printf("-------------------------------------------");
  printf("\nWhat is the tool record #?\n");
  scanf("%d",&row);
  index=tool_index(row);
  printf("What is the tool tool name?\n");
  scanf("%s",&name);
  printf("What is the tool quantity?\n");
  scanf("%d",&quantity);
  printf("What is the tool price?\n");
  scanf("%lf",&cost);
  printf("-------------------------------------------\n");
  oldTool.row=row;
  for(int i=0;i<24;i++){
    oldTool.name[i]=name[i];
  }
  oldTool.quantity=quantity;
  oldTool.cost=cost;
  tools[index]=oldTool;
  All_Tools();
};
void remove_tool(void){
  printf("What is the tool record # that you want to delete: ");
  int j;
  scanf("%d",&j);
  int x=j;
  tool_remover_index(x); 
  All_Tools();
};
void writeToFile(void){
  FILE *fp;
  fp=fopen("hardware.dat","w+");
  fprintf(fp,x);
  for(int i=0;i<100;i++){
    if(tools[i].row!=0){
      fprintf(fp, "\n");
      fprintf(fp, getitem_string(tools[i]));
    }
  }
  fclose(fp);
};
char *p(long int i,char*s,int temp){
  printf(s,"%ld",i);
  return s;
};
char *getitem_string(struct Tool x){
  snprintf(item_string,48,"%d,%s,%d,%lf",x.row,x.name,x.quantity,x.cost);
  return item_string;
};
int tool_index(int x){
    for(int i=0;i<100;i++){
    if(tools[i].row==x){
      return i;
    }
  }
};
struct Tool Line(char myTool[]){
  char delimiter=',';
  double  cost;
  int     itemCount=0;
  int     x; 
  char    name[24];
  int     quant;
  char *p;
  p=strtok (myTool,",");
  while (p!= NULL){
    switch(itemCount){
      case 0:
        x=atoi(p);
        break;
      case 1:
        for(int i=0;i<24;i++){
          name[i]=p[i];
        }
        break;
      case 2:
        quant=atoi(p);
        break;
      case 3:
        sscanf(p, "%lf",&cost);
        break;
    }
    p=strtok(NULL, ",");
    itemCount++;
  }
  struct Tool t;
  t.row=x;
  for(int i=0;i<24;i++){
    t.name[i]=name[i];
  }
  t.quantity=quant;
  t.cost=cost;
  return t;
};
struct Tool tool_get(int x){
  for(int i=0;i<100;i++){
    if(tools[i].row==x){
      return tools[i];
    }
  }
};